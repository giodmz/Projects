from collections.abc import MutableSequence

class MyMutableList(MutableSequence):
    pass

validObject = MyMutableList()
print(validObject)