﻿using ByteBankIO;

class Program
{
    static void Main(string[] args)
    {

        Console.ReadLine();
    }
}