﻿
class Soma {
  
    public int Somar(int a, int b) => a + b;

}
